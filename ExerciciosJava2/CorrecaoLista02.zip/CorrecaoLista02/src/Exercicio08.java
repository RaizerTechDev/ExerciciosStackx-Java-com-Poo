import java.util.Scanner;

//Criar um programa em Java que receba pelo teclado 10 n�meros inteiros
//e informe quantos n�meros digitados s�o �mpares.

public class Exercicio08 {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);

		int contadorImpar = 0;
		
		for (int i = 1; i <= 10; i++) {
			
			System.out.printf("Digite o %s� valor: ", i);
			int n = leitor.nextInt();
			
			if (n % 2 != 0) { // n � �mpar
				contadorImpar++;
			}
			
		}
		
		System.out.printf("Quantidade de N�meros �mpares: %s", contadorImpar);
	}

}
