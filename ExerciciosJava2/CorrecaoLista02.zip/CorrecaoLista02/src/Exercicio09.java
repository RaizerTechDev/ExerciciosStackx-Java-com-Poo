import java.util.Scanner;

//Criar um programa que leia os valores A e B, compare se a soma de A e B � 
//divis�vel por 2 e imprima a resposta na tela.

public class Exercicio09 {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		int a, b, soma;
		
		System.out.print("Qual o valor de A?: ");
		a = leitor.nextInt();

		System.out.print("Qual o valor de B?: ");
		b = leitor.nextInt();
		
		soma = a + b;
		
		if (soma % 2 == 0) {
			System.out.printf("%s � divis�vel por 2!", soma);
		} else {
			System.out.printf("%s N�O � divis�vel por 2!", soma);
		}
	}

}
