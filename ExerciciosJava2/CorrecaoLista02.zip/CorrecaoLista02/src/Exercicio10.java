import java.util.Scanner;

//Criar um programa que leia os valores A, B, N, compare se a soma de A e B � divis�vel por N 
//e imprima a resposta na tela.

public class Exercicio10 {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		int a, b, n, soma;
		
		System.out.print("Qual o valor de A?: ");
		a = leitor.nextInt();

		System.out.print("Qual o valor de B?: ");
		b = leitor.nextInt();
		
		System.out.print("Qual o valor de N?: ");
		n = leitor.nextInt();
		
		soma = a + b;
		
		if (soma % n == 0) {
			System.out.printf("%s � divis�vel por %s!", soma, n);
		} else {
			System.out.printf("%s N�O � divis�vel por %s!", soma, n);
		}
	}

}
